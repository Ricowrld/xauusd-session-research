# Gold Session Study II - Cross-Session Volatility Persistence

The question is whether current Asian realised variance improves London variance forecasts beyond recent London and daily variance. The source is now **2,789,384 complete paired bid/ask M1 candles delivered directly by OANDA for 2016-2023**, in 2,922 original calendar-date response files with SHA-256 manifests.

OANDA reproduces the positive Study I EXP001 range relationship and positive realised-variance association. Validation QLIKE improves **23.9%** against the basic baseline and **20.0%** against the stronger five-/twenty-session baseline. MSE and MAE also improve. These are forecast-loss reductions, not investment returns.

**Overall decision: inconclusive under the registered sample-size gate.** Only 160 development OOS forecasts remain after 400 initial training observations and the fixed source-quality criteria, below the required 500. Validation contains 479 scored forecasts. Do not lower the required count after viewing results. The sole conditional trading candidate remains unrun, and the 2024+ final holdout remains unopened.

## Records

- `preregistration/PROTOCOL.md`, `configs/study.json` and `configs/REGISTERED.json`: original registration.
- Dated implementation and source-role notes: transparent corrections before forecast evaluation.
- `results/oanda`: source inventory, feature/coverage and forecast ledgers, losses, association diagnostics, coefficients and EXP001 reproduction.
- `results/archive_gap_sensitivity`: separate correction to Study I's timestamp-gap calculation; original study files remain frozen.
- `../output/pdf/Gold_Session_Study_II_OANDA_Research_Report.pdf`: full report.

## Reproduce

Install the pinned dependencies in `requirements.txt`. Store your own OANDA practice token in a local environment variable. Tokens must never be pasted into research documents, committed or printed. From this folder:

```
python -m unittest discover -s tests -v
python src/acquire_oanda_bulk.py --start 2016-01-01 --end 2023-12-31 --token-env OANDA_DEMO_TOKEN
python src/forecast.py --provider oanda
python src/replicate_exp001.py --provider oanda
python src/diagnostics.py
python src/archive_gap_sensitivity.py
python src/report.py
```

All acquisition requests outside 2016-2023 are refused. Persistent historical-candle GET requests are used; no order endpoints are called. Empty calendar responses are retained. Actual source bars are never interpolated. The original Study I code/config and cached processed bars are needed to reproduce its separate range comparison and gap sensitivity. They are not mutated by these scripts.

## Limits

Only one primary provider feed is authenticated; the old archive's Dukascopy claim remains provisional. Coverage is especially sparse under the strict complete-M5 rule in earlier years, creating selected-session inference. Association diagnostics are not causal proof. M1 is not ordered-tick execution. No MT5 replay, GC replication, historical news-rule replication or profitable strategy is claimed. Study II creates no trade or Monte Carlo return ledger because its evidence gate is not met.

The project asks about Asian-session information and London behaviour. The frozen Study I acknowledgement credits the original regional-session motivation; external strategy performance is not evidence about gold. Research and implementation assistance: Codex.
