# Gold Session Study II evidence bundle

Read output/pdf/Gold_Session_Study_II_OANDA_Research_Report.pdf first. The numerical
results and code are in gold-session-study-ii; sibling Study I code is an immutable
reference needed by the separately labelled replication and correction.

The report is based on 2,789,384 provider-delivered OANDA paired M1 candles for
2016-2023. Validation QLIKE improves 23.9% against the basic baseline and 20.0%
against the stronger baseline. These are forecast losses, not investment returns.
Development has 160 OOS forecasts versus the preregistered minimum of 500. The
acceptance gate is not met, the trading candidate is unrun, and 2024+ stays locked.

Raw broker responses, credentials, private account information and cached M1
parquet data are excluded. All derived records, public request URLs, source hashes,
protocol records and scripts are included. Follow gold-session-study-ii/README.md
to reacquire the permitted 2016-2023 OANDA history using your own demo token.
Rebuilding the PDF from included saved results needs no API token or raw data:
    python gold-session-study-ii/src/report.py

The archive-gap correction additionally needs Study I's original development and
validation M1 parquet files. Obtain them from the prior local research workspace
or regenerate them from its pinned archive using the frozen download/study code,
for development and validation only. Archive delivery remains unauthenticated.
Do not treat regenerated or later-revised provider prices as bit-identical without
checking their hashes against the included inventories.

report/PROTOCOL_SNAPSHOT.json is a historical preparation snapshot (12 tests and
no empirical results at that stage). report/RESEARCH_STATUS.json and
FINAL_RESULTS_MANIFEST.json describe the completed study (14 checks).
SHA256SUMS.json verifies every other bundle member; it excludes itself.
