# Study III Design Pack

Read output/pdf/Study_III_Design_Pack.pdf and study-iii-design/README.md.
The complete derived availability tables, random-sample recheck results,
power sensitivities, frozen methodology/specification and code are included.
Raw provider responses and credentials are omitted. Full re-acquisition/audit
requires your own provider access and the original Study II workspace. Native
M5 diagnostics are not substitutes for the registered M1-complete target.
No fresh confirmation forecast or trade outcome was evaluated.

Rebuild the PDF without an API token or raw prices:
    python study-iii-design/src/report.py
Verify every other member using BUNDLE_MANIFEST.json. ZIP members preserve
original file bytes; do not convert registered line endings before checking.
