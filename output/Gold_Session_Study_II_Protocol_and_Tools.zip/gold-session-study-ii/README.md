# Gold Session Study II

Separate preregistered follow-up to the permanently archived Study I. Status: **data access pending; no empirical Study II results**. The 2024+ holdout remains unopened.

Read `preregistration/PROTOCOL.md` and `configs/study.json` before running anything. Public Dukascopy endpoints returned HTTP 429 on the recorded probes. HistData's sample download returned an empty response. Neither response is market data.

For an England resident, the practical free independent-data route is an OANDA UK practice account, subject to account-level API/instrument/history verification. Register through OANDA's UK demo page. Generate a personal access token via Manage API Access and store it locally under an environment-variable name of your choosing. Do not paste tokens in chat or write them into research files. The downloader sends GET requests to the practice endpoint only, never order requests, and never logs credentials or account identifiers.

Preparation commands, from this folder:

```
python -m unittest discover -s tests -v
python src/acquire.py dukascopy --start 2016-01-04 --end 2016-01-04
python src/acquire.py oanda --start 2016-01-04 --end 2016-01-04 --token-env YOUR_EXISTING_VARIABLE_NAME
```

Dates are inclusive; all requests outside 2016-2023 are refused. Fetching a sample must confirm paired bid/ask coverage before a full download. The acquisition program stops on rate limits instead of looping aggressively.

After actual complete direct data is acquired:

```
python src/forecast.py --provider dukascopy
python src/replicate_exp001.py --provider dukascopy
```

These commands deliberately fail when source files are absent. They do not reuse Study I's provisional archive as authenticated data. Forecast results alone cannot unlock final data or authorise a profitability claim. The tick trading replay and final-holdout runner are not implemented: their data/specification prerequisites remain unmet.

The source gate requires independent-feed replication as specified in the protocol. A broker demo does not guarantee deep real-tick history. No COMEX history has been acquired. No Study II return, profit factor, drawdown or profitable strategy is claimed.
